import React from 'react';

import './AboutUs.css';

const AboutUs = () => (
  <div>
    AboutUs
  </div>
);

export default AboutUs;
